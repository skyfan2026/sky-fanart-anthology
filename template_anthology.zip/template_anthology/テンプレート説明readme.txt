テンプレート説明

B5t_anthology
ガイド線 AdobePhotoshopで開いた場合

シアン：文字切れ線…文字やデザインなど、断裁されると困る情報はこの線の内側に配置してください。
マゼンタ：仕上がり線…実際の仕上がり位置です。
ブルー：塗足し線…必ずこの範囲までデザインを配置してください。


カンバスサイズは縦横左右3mmずつ塗足しを含めたサイズとなっています。
他ソフトで開いた場合ガイド線が表示されない場合があります。
その場合、上記を参考に3mmずつの間隔を考慮してデータを作成してください。

icon_anthology
テンプレート内のレイヤー（アイコンデータ）いっぱいにアイコン画像を入れてください。

ご不明な点やご質問がございましたら、お問い合わせ欄に記載しております連絡先までお気軽にご連絡ください。




Template Description

B5t_anthology
Guidelines　When opened in Adobe Photoshop

Cyan: Safe Area
Place any text or important elements inside this line to prevent them from being trimmed.
Magenta: Trim Line
This is the final cutting line.
Blue: Bleed Line
Extend your background or artwork to this line.

The document size includes a **3 mm bleed on all sides**.
Guidelines may not be visible when opened in other software.
If so, please use the information above and prepare your file with the 3 mm bleed in mind.

icon_anthology
Please place your icon image so that it fully fills the designated icon area (icon data layer) within the template.

If you have any questions or concerns, please feel free to contact us using the contact information listed in the inquiry section.

Thank you for your cooperation, and we look forward to your participation in SkyArtFest2026.
